/**
 * Clase principal del proyecto
 * @author carlos
 *
 */
public class Clase01 {

	/**
	 * Punto de entrada del proyecto
	 * @param args Parámetros de consola
	 */
	public static void main(String[] args) {
		
		//Comentarios de una sola linea
		/* 
		 * Bloque 
		 * de 
		 * comentarios 
		 * */
		/**
		 * Comentarios Java DOC
		 * Debé colocarse delante de la declaración de método o clase
		 * Es visible desde fuera del archivo binario
		 */
		//TODO Tarea pendiente
		
		//syso ctrol space atajo de teclado para System.out.println
		System.out.println("Hola Mundo!");
		
		//Lenguaje de tipado fuerte		Java C++ C# VBasic
		//Lenguaje de tipado debil		Python PHP javascript
		
		//Tipo de datos primitivos
		
		//Tipo de datos boolean			1byte
		boolean bo=true;				// 1
		System.out.println(bo);
		bo=false;						// 0
		System.out.println(bo);
		
		/*
		 *  0
		 * 	--------
		 * 
		 */
		
		//Tipo de datos byte			1byte		-128 +127
		byte by=-100;
		System.out.println(by);
		
		//Tipo de datos short			2bytes		-32365 32364
		short sh=3000;
		System.out.println(sh);
		
		//Tipo de datos int				4bytes		-2000M a 2000M
		int in=2000000000;
		System.out.println(in);
		
		//Tipo de datos long			8bytes
		long lo=3000000000L;
		System.out.println(lo);
		
		//Tipo de datos char Unicode			2bytes unsigned
		char ch=66;
		System.out.println(ch);
		ch+=32;
		System.out.println(ch);
		ch='x';
		System.out.println(ch);
		System.out.println((int)ch);
		
		// Tipo de datos de punto flotante
		
		// Tipo de datos float 32 bits
		float fl=8.65f;
		System.out.println(fl);
		
		// Tipo de datos double 64 bits
		double dl=8.65;
		System.out.println(dl);
		
		fl=3.25f;
		
		fl=10;
		dl=10;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=100;
		dl=100;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=1000;
		dl=1000;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		//Clase String
		String st="hola";
		System.out.println(st);
		
		String texto="Llego la primavera! Español";
		
		System.out.println("Longitud de texto: "+texto.length());
		
		//Recorrer el string texto
		for(int x=0; x<texto.length();x++) {
			System.out.print(texto.charAt(x));
		}
		System.out.println();
		
		//Imprimir texto en mayusculas
		
		for(int x=0; x<texto.length();x++) {
			char car=texto.charAt(x);
			if(car>=97 && car<=122) 
			{
				car-=32;
			}
			System.out.print(car);
		}
		System.out.println();
		
		for(int x=0; x<texto.length();x++) {
			char car=texto.charAt(x);
			if(car>=97 && car<=122) car-=32;
			System.out.print(car);
		}
		System.out.println();
		
		//Operador Ternario ?
		for(int x=0; x<texto.length();x++) {
			char car=texto.charAt(x);
			System.out.print((car>=97 && car<=122)?(car-=32):car);
		}
		System.out.println();
		
		//Imprimir texto en minusculas
		for(int x=0; x<texto.length();x++) {
			char car=texto.charAt(x);
			System.out.print((car>=65 && car<=90)?(car+=32):car);
		}
		System.out.println();
		
		System.out.println(texto.toUpperCase());
		System.out.println(texto.toLowerCase());
		
		
	}

}
