
public class Saludo {
	public static void main(String[] args) {
		System.out.println("Longitud args: "+args.length);
		for(int a=0; a<args.length; a++) {
			System.out.println(args[a]);
		}
	}
}
