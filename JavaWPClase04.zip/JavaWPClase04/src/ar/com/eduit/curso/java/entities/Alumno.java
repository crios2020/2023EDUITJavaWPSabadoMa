package ar.com.eduit.curso.java.entities;

public class Alumno extends Persona {
    int numeroMatricula;

    public Alumno(String nombre, int edad, Direccion direccion, int numeroMatricula) {
        super(nombre, edad, direccion);
        this.numeroMatricula = numeroMatricula;
    }

    @Override
    public void saludar() {
        System.out.println("Hola soy un alumno!");
    }

    @Override
	public int hashCode() {
		return this.toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return this.hashCode()==obj.hashCode();
	}

	@Override
    public String toString() {
        return "Alumno [numeroMatricula=" + numeroMatricula + "] "+super.toString();
    }

    public int getNumeroMatricula() {
        return numeroMatricula;
    }

}
