package ar.com.eduit.curso.java.utils;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import ar.com.eduit.curso.java.interfaces.I_File;

public class FileText implements I_File  {
    File file=new File("texto.txt");
    @Override
    public String getText() {
        //return "texto de archivo de texto!";
        String text="";
        int car;
        try (FileReader in=new FileReader(file)) {
            while ((car=in.read())!=-1) {
                text+=(char)car;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return text;
    }

    @Override
    public void setText(String text) {
        //System.out.println("Escribiendo archivo de texto!");
        try (FileWriter out=new FileWriter(file)) {
            out.write(text);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
	
}
