package ar.com.eduit.curso.java.entities;

public class ClientePersona {
	
	private int nro;
	private String nombre;
	private int edad;
	private Cuenta cuenta;
	
	//constructores
	
	//Este constructor permite que un cliente sea creado sin una cuenta
//	public ClientePersona(int nro, String nombre, int edad) {
//		this.nro = nro;
//		this.nombre = nombre;
//		this.edad = edad;
//	}

	//Este constructor no permite crear un cliente sin una cuenta
	//una cuenta puede pertenecer a varios clientes
	public ClientePersona(int nro, String nombre, int edad, Cuenta cuenta) {
		this.nro = nro;
		this.nombre = nombre;
		this.edad = edad;
		this.cuenta = cuenta;
	}
	
	//Este constructor no permite crear un cliente sin una cuenta
	//una cuenta solo pertenece a un cliente
	public ClientePersona(int nro, String nombre, int edad, int nroCuenta, String monedaCuenta) {
		this.nro = nro;
		this.nombre = nombre;
		this.edad = edad;
		this.cuenta = new Cuenta(nroCuenta, monedaCuenta);
	}

	public void comprar() {
		System.out.println("Se realizo una compra!");
	}
	
	@Override
	public String toString() {
		return "ClientePersona [nro=" + nro + ", nombre=" + nombre + ", edad=" + edad + ", cuenta=" + cuenta + "]";
	}

	public int getNro() {
		return nro;
	}

	public String getNombre() {
		return nombre;
	}

	public int getEdad() {
		return edad;
	}

	public Cuenta getCuenta() {
		return cuenta;
	}
	
}
