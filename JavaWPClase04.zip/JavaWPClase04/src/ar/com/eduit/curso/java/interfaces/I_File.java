package ar.com.eduit.curso.java.interfaces;

public interface I_File {
	
	/**
	 * Este método escribe en un archivo
	 * @param text texto a escribir
	 */
	void setText(String text);
	
	/**
	 * Este método lee el archivo
	 * @return texto del archivo
	 */
	String getText();
	
	//Interfaces en Java 8 - Métodos default
	default void info() {
		System.out.println("Interface I_File");
	}
	
}
