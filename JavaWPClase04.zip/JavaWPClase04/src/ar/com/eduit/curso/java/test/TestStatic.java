package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Auto;

public class TestStatic {
    public static void main(String[] args) {
        
        Auto.acelerar();                //10

        System.out.println("-- auto1 --");
        Auto auto1=new Auto("Ford", "Ka", "Negro");
        auto1.acelerar();           //20
        auto1.acelerar();           //30
        System.out.println(auto1+", "+auto1.getVelocidad());

        System.out.println("-- auto2 --");
        Auto auto2=new Auto("Fiat", "Toro", "Bordo");
        auto2.acelerar();           //40
        System.out.println(auto2+", "+auto2.getVelocidad());
        System.out.println(auto1+", "+Auto.getVelocidad());

    }
}
