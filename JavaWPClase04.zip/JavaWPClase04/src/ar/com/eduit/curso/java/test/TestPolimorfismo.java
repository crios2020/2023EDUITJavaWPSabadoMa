package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestPolimorfismo {

	public static void main(String[] args) {
		//Polimorfismo - Poliformismo

		//Persona persona0=new Persona("Juan",34,new Direccion("Lima",22,"1","a"));
		Persona persona1=new Vendedor("Alberto",45,new Direccion("Viel",33,"1","a"),1,500000);
		Persona persona2=new Cliente("Ana",26,new Direccion("Peru",65,"1","a"),1,new Cuenta(1,"arg$"));
		
		persona1.saludar();
		persona2.saludar();
		
		Vendedor vendedor1;
		//vendedor1=(Vendedor)persona1;
		vendedor1=(persona1 instanceof Vendedor)?(Vendedor)persona1:null;
		//if(persona1 instanceof Vendedor) {
		//	vendedor1=(Vendedor)persona1;
		//}else {
		//	vendedor1=null;
		//}
		
		Object obj;
		obj=2;
		obj="hola";
		obj=vendedor1;
		
		String texto="hola";
		
		//Clase Class
		System.out.println(persona1.getClass());
		System.out.println(persona1.getClass().getName());
		System.out.println(persona1.getClass().getSimpleName());
		System.out.println(persona1.getClass().getPackageName());
		System.out.println(persona1.getClass().descriptorString());
		System.out.println(persona1.getClass().getSuperclass().getName());
		System.out.println(persona1.getClass().getSuperclass().getSuperclass().getName());
		System.out.println(persona1.getClass().getSuperclass().getSuperclass().getSuperclass());
		System.out.println(texto.getClass());
		System.out.println(texto.getClass().getSuperclass());
		
		
		
	}

}
