package ar.com.eduit.curso.java.test;

import java.util.Scanner;

import ar.com.eduit.curso.java.interfaces.I_File;
import ar.com.eduit.curso.java.utils.FileBinary;
import ar.com.eduit.curso.java.utils.FileText;

public class TestInterfaces {
    public static void main(String[] args) throws Exception {
        I_File file=null;

        //file=new FileText();
        //file=new FileBinary();

        System.out.print("Ingrese FileText o FileBinary: ");
        String in=new Scanner(System.in).next();
        //if(in.equalsIgnoreCase("FileText"))     file=new FileText();
        //if(in.equalsIgnoreCase("FileBinary"))   file=new FileBinary();

        //file=(I_File)Class.forName("ar.com.eduit.curso.java.utils."+in).newInstance();
        file=(I_File)Class.forName("ar.com.eduit.curso.java.utils."+in).getConstructor().newInstance();

        //app
        file.setText("hola a todos!! curso de Java");
        System.out.println(file.getText());
        file.info();
    }
}
