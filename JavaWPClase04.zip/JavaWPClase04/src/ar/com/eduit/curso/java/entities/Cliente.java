package ar.com.eduit.curso.java.entities;

public class Cliente extends Persona{
	
	private int nro;
	private Cuenta cuenta;
	
	public Cliente(String nombre, int edad, Direccion direccion, int nro, Cuenta cuenta) {
		super(nombre, edad, direccion);
		this.nro = nro;
		this.cuenta = cuenta;
	}

	@Override
	public void saludar() {
		System.out.println("Hola soy un Cliente!");
	}

	@Override
	public String toString() {
		return "Cliente [nro=" + nro + ", cuenta=" + cuenta + ", Datos personales=" + super.toString() + "]";
	}

	public int getNro() {
		return nro;
	}

	public Cuenta getCuenta() {
		return cuenta;
	}
	
}
