package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Direccion;

public class TestObject {
    public static void main(String[] args) {
        
        Alumno alumno1=new Alumno("Jose", 30, new Direccion("Lima", 22, "1", "a"), 1);
        Alumno alumno2=alumno1;
        Alumno alumno3=new Alumno(alumno1.getNombre(),alumno1.getEdad(),alumno1.getDireccion(),alumno1.getNumeroMatricula());
    
        System.out.println(alumno1+", "+alumno1.hashCode());
        System.out.println(alumno2+", "+alumno2.hashCode());
        System.out.println(alumno3+", "+alumno3.hashCode());
    
        System.out.println(alumno1.equals(alumno2));            //true
        System.out.println(alumno1.equals(alumno3));            //true

    }
}
