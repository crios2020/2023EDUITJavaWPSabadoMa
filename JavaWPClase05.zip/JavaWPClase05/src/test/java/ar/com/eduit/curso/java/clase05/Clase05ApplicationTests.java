package ar.com.eduit.curso.java.clase05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
