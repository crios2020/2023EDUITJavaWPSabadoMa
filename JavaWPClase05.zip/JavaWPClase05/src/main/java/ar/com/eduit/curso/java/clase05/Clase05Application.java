package ar.com.eduit.curso.java.clase05;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase05Application {

	public static void main(String[] args) {
		//SpringApplication.run(Clase05Application.class, args);
		System.out.println("Hola Mundo!");

		//para ejecutar F5 o botón run
		//para compilar en consola bash sh mvnw package
		//para ejecutar desde consola bash java -jar clase05.jar

		//Manejo de Exceptions
		//System.out.println(10/0);
		//System.out.println("Esta sentencia no se ejecuta!");

		//Estructura try - catch - finally
		/*
		try{										//Obligatorio
			//colocar las sentencias que pueden arrojar una exception
			//estas sentencias tienen un costo mayor de hardware
			//Si las sentencias se ejecutan sin probleas el bloque termina normalmente
			//y continua la ejecuciòn en el bloque finally o después de catch
			//Si existe una exception (error) el bloque try detiene su ejecución y continua 
			//el control de ejecución en el bloque catch (no se detiene el programa)
		} catch(Exception e){						//Obligatorio
			//este bloque se ejecuta en caso de exception en el bloque try
			//Se recibe un objeto de la clase Exception con detalles del error
			//cuando termina este bloque continua el control de ejecución en el bloque finally 
			//o finaliza la estructura.
		} finally{									//Opcional
			//Este bloque se ejecuta siempre, ocurra una exception o no 
			//Las variables declaradas en bloque try o catch estan fuera de alcance(scope)
		}
		//el programa termina normalmente
		*/

		try {
			//System.out.println(10/0);		//Arroja una Excpetion
			//System.out.println("Esta sentencia no se ejecuta");
		} catch (Exception e) {
			System.out.println("Ocurrio un error!!!");
			//System.out.println(e);							//Impresión sincronica
			//System.err.println(e);								//Impresión asincronica
			e.printStackTrace();								//Impresión asincronica
		} finally {
			//System.out.println("El programa termina normalmente");
		}

		/*
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.out.println("Hola Mundo!");
		System.err.println("Hola Mundo!");
		*/

		//GeneradorExceptions.generar();				//UncheckedException
		//FileReader in=new FileReader("texto.txt");	//CheckedException
		try {
			//GeneradorExceptions.generar();
			//GeneradorExceptions.generar(true);
			//GeneradorExceptions.generar("26x");
			//GeneradorExceptions.generar(null,2);
			//GeneradorExceptions.generar("hola", 20);
			//FileReader in=new FileReader("texto.txt");
		} catch (Exception e) {
			System.out.println(e);
		}
		
		//Captura de Exceptions personalizadas
		try {
			//GeneradorExceptions.generar();
			//GeneradorExceptions.generar(true);
			//GeneradorExceptions.generar("26x");
			//GeneradorExceptions.generar(null,2);
			//GeneradorExceptions.generar("hola", 20);
			FileReader in=new FileReader("texto.txt");
		//} catch (ArrayIndexOutOfBoundsException e) 	{ System.out.println("Indice fuera de rango!");
		} catch (ArithmeticException e) 			{ System.out.println("División /0");
		} catch (NumberFormatException e) 			{ System.out.println("Formato de número incorrecto!");
		} catch (NullPointerException e) 			{ System.out.println("Puntero Nulo!");
		//} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice Fuera de rango!");
		//} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { System.out.println("Indice Fuera de rango!");
		} catch (IndexOutOfBoundsException e) 		{ System.out.println("Indice Fuera de rango!");
		} catch (FileNotFoundException e) 			{ System.out.println("No se encontro el archivo!"); 
		} catch (IOException e)						{ System.out.println("Error de E/S!");
		} catch (Exception e) 						{ System.out.println("Ocurrio un error no esperado!"); }

		//Uso de Exceptions para validar reglas de negocio
		Vuelo v1=new Vuelo("AER1234", 100);
		Vuelo v2=new Vuelo("FLY1111", 100);

		try {
			v1.venderPasajes(50);
			v2.venderPasajes(20);
			v1.venderPasajes(40);
			v2.venderPasajes(10);
			v1.venderPasajes(30); 			//lanza Exception
			v2.venderPasajes(30);			//Esta venta no se ejecuta!
		} catch (NoHayMasPasajesException e) {
			System.out.println(e);
		}

		System.out.println(v1);
		System.out.println(v2);

		System.out.println("Fin del programa!");


		//TODO Uso de Try with Resources


	}

}
