package ar.com.eduit.curso.java.clase05;

public class GeneradorExceptions {
    public static void generar(){
        int[] vector=new int[5];
        vector[20]=10;
    }
    public static void generar(boolean x){
        if(x) System.out.println(10/0);
    }
    public static void generar(String nro){             //"38x"
        int numero=Integer.parseInt(nro);
    }
    public static void generar(String texto, int index){        //"hola",20
        //if(texto==null || texto.length()<=index) return;
        System.out.println(texto.charAt(index));
    }
}
