package ar.com.eduit.curso.java.clase05;

public class Vuelo {
    private String nombre;
    private int pasajesDisponibles;

    public Vuelo(String nombre, int pasajesDisponibles) {
        this.nombre = nombre;
        this.pasajesDisponibles = pasajesDisponibles;
    }

    public synchronized void venderPasajes(int cantidadPasajesPedidos) throws NoHayMasPasajesException{
        if(pasajesDisponibles<cantidadPasajesPedidos) 
                throw new NoHayMasPasajesException(nombre, pasajesDisponibles, cantidadPasajesPedidos);
        pasajesDisponibles-=cantidadPasajesPedidos;
    }

    @Override
    public String toString() {
        return "Vuelo [nombre=" + nombre + ", pasajesDisponibles=" + pasajesDisponibles + "]";
    }

    
}
