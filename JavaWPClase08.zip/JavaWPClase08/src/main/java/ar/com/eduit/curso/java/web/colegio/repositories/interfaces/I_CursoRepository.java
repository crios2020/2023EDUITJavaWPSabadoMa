package ar.com.eduit.curso.java.web.colegio.repositories.interfaces;

import java.util.List;

import ar.com.eduit.curso.java.web.colegio.entities.Curso;

public interface I_CursoRepository {
    void save(Curso curso);
    void remove(Curso curso);
    void update(Curso curso);
    List<Curso>getAll();
    Curso getById(int id);
    List<Curso>getLikeTitulo(String titulo);
    List<Curso>getLikeTituloProfesor(String titulo, String profesor);
    int getCantidadAlumnos();
}
