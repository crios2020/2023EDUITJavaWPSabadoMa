package ar.com.eduit.curso.java.web.colegio.repositories.jdbc;

import java.util.List;

import ar.com.eduit.curso.java.web.colegio.entities.Alumno;
import ar.com.eduit.curso.java.web.colegio.entities.Curso;
import ar.com.eduit.curso.java.web.colegio.repositories.interfaces.I_AlumnoRepository;

public class AlumnoRepository implements I_AlumnoRepository{

    @Override
    public void save(Alumno alumno) {
        // TODO realizar método guardar alumno
        throw new UnsupportedOperationException("Unimplemented method 'save'");
    }

    @Override
    public void remove(Alumno alumno) {
        // TODO realizar método borrar alumno
        throw new UnsupportedOperationException("Unimplemented method 'remove'");
    }

    @Override
    public void update(Alumno alumno) {
        // TODO realizar método actualizar alumno
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public List<Alumno> getAll() {
        // TODO realizar método obtener todos los alumnos
        throw new UnsupportedOperationException("Unimplemented method 'getAll'");
    }

    @Override
    public Alumno getById(int id) {
        // TODO realizar método obtener por id
        throw new UnsupportedOperationException("Unimplemented method 'getById'");
    }

    @Override
    public List<Alumno> getLikeApellido(String apellido) {
        // TODO realizar método obtener por apellido
        throw new UnsupportedOperationException("Unimplemented method 'getLikeApellido'");
    }

    @Override
    public List<Alumno> getByCurso(Curso curso) {
        // TODO realizar método obtener por curso
        throw new UnsupportedOperationException("Unimplemented method 'getByCurso'");
    }
    
}
