package ar.com.eduit.curso.java.web.colegio.repositories.interfaces;

import java.util.List;

import ar.com.eduit.curso.java.web.colegio.entities.Alumno;
import ar.com.eduit.curso.java.web.colegio.entities.Curso;

public interface I_AlumnoRepository {
    void save(Alumno alumno);
    void remove(Alumno alumno);
    void update(Alumno alumno);
    List<Alumno>getAll();
    Alumno getById(int id);
    List<Alumno>getLikeApellido(String apellido);
    List<Alumno>getByCurso(Curso curso);
}
