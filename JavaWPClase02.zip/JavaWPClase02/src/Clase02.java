
public class Clase02 {
	public static void main(String[] args) {
		System.out.println("Clase 2 POO");
		
		//Clases en Java: es un objeto de la clase java.lang.Class
		//Atributos en Java: es un objeto de la clase java.lang.reflect.Field
		//Los atributos se inicializan automáticamente, los atributos numéricos se inician en 0
		//los atributos String se inicalizan en null.
		//Métodos en Java: es un objetos de la clase java.lang.reflect.Method
		//Métodos constructores en java: es un objeto de la clase java.lang.reflect.Constructor
		//Si una clase no tiene constructor, Java va a agregar un constructor vacio 
		// en tiempo de compilación.
		//Un constructor puede sobrecargarse, y sirve para inicializar un objeto.
		
		int x;
		String t;
		//System.out.println(x); //Error no se puede imprimir una variable no inicializada
		//System.out.println(t);
		
		//auto1
		System.out.println("-- auto1 --");
		
		//Creamos un objeto de la clase Auto
		Auto auto1=new Auto();					//new Auto() - llama al constructor de la clase
		
		//Ponemos estado al objeto (valor en sus atributos)
		auto1.marca="Ford";
		auto1.modelo="Ka";
		auto1.color="Negro";
		
		//invocamos métodos
		auto1.acelerar();		// 10
		auto1.acelerar();		// 20
		auto1.acelerar();		// 30
		auto1.frenar();			// 20
		auto1.acelerar(23); 	// 43
		auto1.acelerar(12);  	// 55
		
		//imprimimos el estado del objeto
		System.out.println(auto1.marca+", "+auto1.modelo+", "+auto1.color+", "+auto1.velocidad);
				
		System.out.println("-- auto2 --");
		Auto auto2=new Auto();
		auto2.marca="Fiat";
		auto2.modelo="Toro";
		auto2.color="Bordo";
		for(int a=0; a<=26; a++) {
			auto2.acelerar();
		}
		System.out.println(auto2.marca+", "+auto2.modelo+", "+auto2.color+", "+auto2.velocidad);
		
		auto2.imprimirVelocidad();
		System.out.println(auto2.obtenerVelocidad());
		
		//método toString()
		System.out.println(auto2.toString());
		System.out.println(auto2);

		System.out.println("-- auto3 --");
		Auto auto3=new Auto("Peugeot","3008","Gris");
		auto3.acelerar(75);
		System.out.println(auto3);
		
	}
}
