package ar.com.eduit.curso.java.clase02;

public class Empleado {
	
	private int nroLegago;
	private String nombre;
	private String apellido;
	private double sueldoBasico;

	public Empleado(int nroLegago, String nombre, String apellido, double sueldoBasico) {
		this.nroLegago = nroLegago;
		this.nombre = nombre;
		this.apellido = apellido;
		this.sueldoBasico = sueldoBasico;
	}

	@Override
	public String toString() {
		return "Empleado [nroLegago=" + nroLegago + ", nombre=" + nombre + ", apellido=" + apellido + ", sueldoBasico="
				+ sueldoBasico + "]";
	}

	public int getNroLegago() {
		return nroLegago;
	}

	public void setNroLegago(int nroLegago) {
		this.nroLegago = nroLegago;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public double getSueldoBasico() {
		return sueldoBasico;
	}

	public void setSueldoBasico(double sueldoBasico) {
		this.sueldoBasico = sueldoBasico;
	}

}
