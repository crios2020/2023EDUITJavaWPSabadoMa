package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cuenta;

public class TestDiagramaRelaciones {
	
	public static void main(String[] args) {
		//Test de Objetos Mocks(Objetos Simulados)
		
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1,"args");
		cuenta1.depositar(13000);
		cuenta1.depositar(36000);
		cuenta1.debitar(25000);
		cuenta1.debitar(40000);
		System.out.println(cuenta1);
		
		
	}
	
}
