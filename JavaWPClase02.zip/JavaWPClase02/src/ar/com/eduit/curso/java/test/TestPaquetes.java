package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.clase02.Auto;
import ar.com.eduit.curso.java.clase02.CuentaX;
import ar.com.eduit.curso.java.clase02.Empleado;

public class TestPaquetes {

	public static void main(String[] args) {
		Auto auto;
		auto=new Auto();		
		//auto.acelerar();	//Error de visibilidad
		System.out.println(auto);
		
		Empleado empleado=new Empleado(1,"Cristian","Molina",4000);
		System.out.println(empleado);
		
		CuentaX cuenta=new CuentaX(1,"agr$");
		//cuenta.saldo=2799329;
		cuenta.depositar(999999);
		System.out.println(cuenta);
		
	}

}
