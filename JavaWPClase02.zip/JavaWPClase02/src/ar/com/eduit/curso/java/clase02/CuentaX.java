package ar.com.eduit.curso.java.clase02;

public class CuentaX {
	private int numero;
	private String moneda;
	private double saldo;

	public CuentaX(int numero, String moneda) {
		this.numero = numero;
		this.moneda = moneda;
	}

	public void depositar(double monto) {
		saldo+=monto;
	}
	
	public void debitar(double monto) {
		if(saldo>=monto) {
			saldo-=monto;
		}else {
			System.out.println("Saldo insuficiente");
		}
	}

	@Override
	public String toString() {
		return "CuentaX [numero=" + numero + ", moneda=" + moneda + ", saldo=" + saldo + "]";
	}

}
