package ar.com.eduit.curso.java.clase02;

//Declaración de clase
public class Auto {

	//atributos
	String marca;
	String modelo;
	String color;
	int velocidad;
	/**
	 * Este método fue deprecado por Carlos Rios el 23/09/23
	 * por ser inseguro!
	 * usar en su reemplazo  Auto(String marca, String modelo, String color)
	 */
	@Deprecated      //Annotation JDK 5
	public Auto(){} // constructor vacio
	
	//método constructor
	Auto(String marca, String modelo, String color){
		this.marca=marca;
		this.modelo=modelo;
		this.color=color;
	}
	
	//métodos
	void acelerar() {
		//velocidad+=10;
		//if(velocidad>=100) velocidad=100;
		acelerar(10);		//llamado de método dentro de la misma clase
	}//end method acelerar
	
	//sobrecarga de métodos
	//métodos con ingreso de parámetros
	/**
	 * Método para acelerar
	 * @param kilometros cantidad de kilometros a acelerar
	 */
	void acelerar(int kilometros) {
		velocidad+=kilometros;
		if(velocidad>=100) velocidad=100;
	}
	
	void frenar() {
		velocidad-=10;
	}
	
	//método void, sin devolución de parámetros(valor)
	void imprimirVelocidad() {
		System.out.println(velocidad);
	}
	
	//método con devolución de parámetro(valor)
	int obtenerVelocidad() {
		return velocidad;
	}

	@Override
	public String toString() {
		return marca+", "+modelo+", "+color+", "+velocidad;
	}
	
}//end class
