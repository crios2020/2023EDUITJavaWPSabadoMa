package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;

public class TestDiagramaHerencia {
	
	public static void main(String[] args) {
		
		System.out.println("-- direccion1 --");
		Direccion direccion1=new Direccion("Lima",222,"4","e");
		System.out.println(direccion1);
		
		System.out.println("-- direccion2 --");
		Direccion direccion2=new Direccion("Belgrano", 49, null, null, "Morón");
		System.out.println(direccion2);
		
		/*
		System.out.println("-- persona1 --");
		Persona persona1=new Persona("Juan", 26, direccion1);
		System.out.println(persona1);
		persona1.saludar();
		
		System.out.println("-- persona2 --");
		Persona persona2=new Persona("Andrea", 25, persona1.getDireccion());
		System.out.println(persona2);
		persona2.saludar();
		*/
		
		System.out.println("-- vendedor1 --");
		Vendedor vendedor1=new Vendedor("Karina Vasquez", 38, direccion2, 1, 250000);
		System.out.println(vendedor1);
		vendedor1.saludar();
		
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1,"args");
		cuenta1.depositar(13000);
		cuenta1.depositar(36000);
		cuenta1.debitar(25000);
		cuenta1.debitar(40000);
		System.out.println(cuenta1);
		
		System.out.println("-- cliente1 --");
		Cliente cliente1=new Cliente("Juan Vargas", 23, direccion1, 1, cuenta1);
		System.out.println(cliente1);
		cliente1.saludar();
		
		//TODO polimorfismo
		
		//TODO Interfaces
		
		//TODO Polimorfismo por interfaces
		
		//TODO static
		
		
	}
	
}
