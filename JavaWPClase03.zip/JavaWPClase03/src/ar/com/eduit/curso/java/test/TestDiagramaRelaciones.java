package ar.com.eduit.curso.java.test;

import java.util.ArrayList;
import java.util.List;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;

public class TestDiagramaRelaciones {
	
	public static void main(String[] args) {
		
		//Test de Objetos Mocks(Objetos Simulados)
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1=new Cuenta(1,"args");
		cuenta1.depositar(13000);
		cuenta1.depositar(36000);
		cuenta1.debitar(25000);
		cuenta1.debitar(40000);
		System.out.println(cuenta1);
		
		System.out.println("-- clientePersona1 --");
		ClientePersona clientePersona1=new ClientePersona(1,"Ana Gallardo",43, new Cuenta(2,"args"));
		clientePersona1.getCuenta().depositar(250000);
		clientePersona1.getCuenta().depositar(450000);
		System.out.println(clientePersona1);
		
		System.out.println("-- clientePersona2 --");
		ClientePersona clientePersona2=new ClientePersona(2,"Cristian Molina",43, clientePersona1.getCuenta());
		clientePersona2.getCuenta().debitar(120000);
		System.out.println(clientePersona2);
		System.out.println(clientePersona1);
		
		System.out.println("-- clientePersona3 --");
		ClientePersona clientePersona3=new ClientePersona(3,"Eliana Correa",29, 3,"args");
		clientePersona3.getCuenta().depositar(870000);
		clientePersona3.getCuenta().debitar(230000);
		System.out.println(clientePersona3);
		
		System.out.println("-- clienteEmpresa1 --");
		ClienteEmpresa clienteEmpresa=new ClienteEmpresa(1, "Todo Limpio srl", "Viel 234");
		ArrayList<Cuenta> cuentasEmpresa=clienteEmpresa.getCuentas();
		cuentasEmpresa.add(new Cuenta(10,"args"));			// 0
		cuentasEmpresa.add(new Cuenta(11,"reales"));		// 1
		cuentasEmpresa.add(new Cuenta(12,"U$S"));			// 2
		cuentasEmpresa.get(0).depositar(660000);
		cuentasEmpresa.get(0).debitar(890000);
		cuentasEmpresa.get(0).debitar(330000);
		cuentasEmpresa.get(1).depositar(50000);
		cuentasEmpresa.get(2).depositar(12000);
		System.out.println(clienteEmpresa);
		System.out.println(cuentasEmpresa);
		//for(int a=0; a<cuentasEmpresa.size(); a++) System.out.println(cuentasEmpresa.get(a));
		//for(Cuenta cuenta:cuentasEmpresa) System.out.println(cuenta);
		cuentasEmpresa.forEach(cuenta->System.out.println(cuenta));
		
		//int[] numeros= {2,4,6,8};
		ArrayList<Integer>numeros=new ArrayList();
		numeros.addAll(List.of(2, 4, 6, 8));
		numeros.add(10);
		for(int numero:numeros) System.out.println(numero);
	}
	
}
