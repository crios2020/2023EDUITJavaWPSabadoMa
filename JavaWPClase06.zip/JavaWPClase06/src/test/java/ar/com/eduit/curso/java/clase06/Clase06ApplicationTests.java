package ar.com.eduit.curso.java.clase06;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase06ApplicationTests {

	@Test
	void contextLoads() {
	}

}
