package ar.com.eduit.curso.java.web.colegio.entities;

import ar.com.eduit.curso.java.web.colegio.enums.Dia;
import ar.com.eduit.curso.java.web.colegio.enums.Turno;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Curso {

    private int id;
    private String titulo;
    private String profesor;
    private Dia dia;
    private Turno turno;
    
    public Curso() {
    }

    public Curso(String titulo, String profesor, Dia dia, Turno turno) {
        this.titulo = titulo;
        this.profesor = profesor;
        this.dia = dia;
        this.turno = turno;
    }

}
