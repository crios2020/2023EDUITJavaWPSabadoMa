package ar.com.eduit.curso.java.clase06;

public enum EstadoCivil {
    SOLTERO,
    CASADO,
    VIUDO,
    DIVORCIADO
}
