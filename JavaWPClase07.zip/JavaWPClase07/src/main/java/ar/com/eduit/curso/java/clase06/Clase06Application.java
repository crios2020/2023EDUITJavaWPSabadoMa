package ar.com.eduit.curso.java.clase06;

import java.io.FileWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class Clase06Application {

	public static void main(String[] args) {
		//SpringApplication.run(Clase06Application.class, args);

		//Esto no se debe hacer!!!
		/*
		FileWriter out=null;
		try {
			out=new FileWriter("texto.txt");
			out.write("Hola a todos");
			out.close();
		} catch (Exception e) {
			System.out.println(e);
			//out.close();
		} finally{
			try {
				out.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		*/

		// try with resources			JDK 7 o superior
		try (FileWriter out=new FileWriter("texto.txt")) {
			out.write("Hola a todos");
		} catch (Exception e) {
			System.out.println(e);
		}

		//Arrays o Vectores
		Auto[] autos=new Auto[4];
		autos[0]=new Auto("WV","Gol","Blanco");
		autos[1]=new Auto("Fiat","Toro","Gris");
		autos[2]=new Auto("Ford","Bronco","Negro");
		autos[3]=new Auto("Citroen","C4","Rojo");

		//recorrido del vector autos
		//reccorido usando indices
		// for(int a=0; a<autos.length; a++){
		// 	System.out.println(autos[a]);
		// }

		//recorrido forEach
		//for (Auto auto : autos) {
		//	System.out.println(auto);
		//}

		List.of(autos).forEach(System.out::println);

		//Collecciones
		//Interface List (Simula un vector dinamico, y usa indices)
		List lista1;						//tipo Object
		
		lista1=new ArrayList();
		//lista1=new Vector();
		//lista1=new LinkedList();

		lista1.add(new Auto("Renault","Kangoo","Blanco"));		// 0
		lista1.add(new Auto("Peugeot","308","Negro"));			// 1
		lista1.add(new Auto("Citroen","Berlingo","Rojo"));		// 2
		lista1.add("hola");														// 3
		lista1.add("chau");														// 4
		lista1.add(26);															// 5

		lista1.add(2,"Java");
		lista1.remove(5);

		System.out.println(lista1.get(2));

		//Copiar todos los autos del vector autos a lista1
		for(Auto auto: autos) lista1.add(auto);


		System.out.println("*******************************************************");

		//Recorrido por indices
		// for(int a=0; a<lista1.size(); a++){
		// 	System.out.println(lista1.get(a));
		// }

		//Recorrido foreach
		//for(Object obj: lista1) System.out.println(obj);

		//Método forEach()		JDK 8 o sup
		//lista1.forEach(obj->System.out.println(obj));

		// lista1.forEach(obj->{
		// 	System.out.println(obj);
		// });
		
		lista1.forEach(System.out::println);

		//Uso de Generics <>			JDK 5 o sup
		List<Auto>lista2=new ArrayList();					//Auto
		lista2.add(new Auto("Chryslerr","Caravan","Rojo"));
		lista2.add(new Auto("Chryslerr","Caravan","Rojo"));

		Auto auto1=(Auto)lista1.get(0);
		Auto auto2=lista2.get(0);

		//Copiar los autos de lista1 a lista2
		lista1.forEach(obj->{
			if(obj instanceof Auto) lista2.add((Auto)obj);
		});

		System.out.println("*******************************************************");
		lista2.forEach(System.out::println);


		//Interface Set			Set no tiene indices y no permite valores duplicados
		Set<String>setSemana=null;

		//Implmementación HashSet: es la más veloz, pero no garantiza el orden de los elementos
		//setSemana=new HashSet();

		//Implementación LinkedHashSet: almacena elementos en una lista enlazada, por orden de ingreso
		//setSemana=new LinkedHashSet();

		//Implementación TreeSet: almacena elementos en un arbol B, por orden nátural		
		setSemana=new TreeSet();

		setSemana.add("lunes");
		setSemana.add("martes");
		setSemana.add("miércoles");
		setSemana.add("jueves");
		setSemana.add("jueves");
		setSemana.add("viernes");
		setSemana.add("sábado");
		setSemana.add("domingo");
		setSemana.add("lunes");
		setSemana.add("martes");
		setSemana.add("lunes");
		setSemana.forEach(System.out::println);

		Set<Integer>numeros;
		//numeros=new TreeSet();
		//numeros=new LinkedHashSet();
		numeros=new HashSet();
		numeros.add(34);
		numeros.add(26);
		numeros.add(23);
		numeros.add(46);
		numeros.add(65);
		numeros.add(29);
		numeros.add(39);
		numeros.add(38);
		numeros.forEach(System.out::println);

		Set<Auto> setAutos;
		//setAutos=new LinkedHashSet();
		setAutos=new TreeSet();
		setAutos.addAll(lista2);
		setAutos.add(new Auto("Renault","Kangoo","Blanco"));
		setAutos.add(new Auto("Citroen","Berlingo","Blanco"));
		setAutos.add(new Auto("Citroen","Berlingo","Azul"));
		setAutos.add(new Auto("Citroen","C5","Blanco"));
		setAutos.add(new Auto("Citroen","C3","Blanco"));
		//setAutos.forEach(System.out::println);
		setAutos.forEach(auto->System.out.println(auto+"\t"+auto.hashCode()));


		//println("Hola Mundo");
		//System.out.println("Hola Mundo");
		//Response.out.println("Hola Mundo");
		//FileWriter.out.println("Hola Mundo");


		/*
		 * 	Pila LIFO		Last In First Out	(El ultimo elementos en entrar es el primer elemento en salir)
		 * 
		 * 	Cola FIFO		First In First Out (El primer elemento en entrar es el primer elemento en salir)
		 * 
		 */

		//Pilas y Colas

		//Clase Stack		Pilas
		Stack<Auto>pilaAutos=new Stack();
		//método .push() Encolar un elemento
		pilaAutos.push(new Auto("Chevrolet","Meriva","Gris"));
		pilaAutos.addAll(lista2);

		System.out.println("**************************************************");
		pilaAutos.forEach(System.out::println);
		System.out.println("Longitud de pila: "+pilaAutos.size());
		while(!pilaAutos.isEmpty()){
			//método .pop() desapila un elemento
			System.out.println(pilaAutos.pop());
		}
		System.out.println("Longitud de pila: "+pilaAutos.size());

		//Clase ArrayDeque	Colas
		ArrayDeque<Auto> colaAutos=new ArrayDeque();
		//método .offer() encola un elemento
		colaAutos.offer(new Auto("Chery","qq","Rojo"));
		colaAutos.addAll(lista2);
		System.out.println("**************************************************");
		colaAutos.forEach(System.out::println);
		
		System.out.println("Longitud de cola: "+colaAutos.size());
		while (!colaAutos.isEmpty()) {
			//método .poll() desencola un elemento
			System.out.println(colaAutos.poll());
		}
		System.out.println("Longitud de cola: "+colaAutos.size());

		//Interface Map: Representa un diccionario o vector asociativo, es decir un arreglo
		//					del tipo llave, valor

		//Map<Empleado,Auto>mapaEmpledosAutos;

		Map<String,String>mapaSemana=null;

		//Implementación TreeMap: es la más veloz, pero orden no garantiza el orden de los elementos
		//mapaSemana=new HashMap();

		//Implementación Hashtable: es similar a TreeMap, pero es legacy, no se recomienda su uso
		//mapaSemana=new HashMap();

		//Implementación LinkedHashMap:	almacena los elementos en una lista enlazada por orden de ingreso
		mapaSemana=new LinkedHashMap();

		//Implementación TreeMap:	almacena elementos en un arbol por orden natural de la llave
		//mapaSemana=new TreeMap();

		mapaSemana.put("lu","Lunes");
		mapaSemana.put("ma","Martes");
		mapaSemana.put("mi","Miércoles");
		mapaSemana.put("ju","Jueves");
		mapaSemana.put("vi","Viernes");
		mapaSemana.put("sa","Sábado");
		mapaSemana.put("do","Domingo");
		System.out.println(mapaSemana.get("sa"));
		mapaSemana.forEach((k,v)->System.out.println(k+": "+v));

		System.out.println(System.getProperty("user.country"));

		//Mapa de Systema
		System.out.println(System.getProperties());
		System.getProperties().forEach((p,v)->System.out.println(p+": "+v));

		System.out.println("*******************************************");
		System.out.println(System.getProperty("os.name"));
		System.out.println(System.getProperty("os.version"));
		System.out.println(System.getProperty("os.arch"));
		System.out.println(System.getProperty("java.version"));
		System.out.println(System.getProperty("java.vm.name"));
		System.out.println(System.getProperty("user.name"));
		System.out.println(System.getProperty("user.home"));
		System.out.println(System.getProperty("user.language"));

		System.out.println(System.getenv());
		System.getenv().forEach((k,v)->System.out.println(k+": "+v));
		System.out.println("***************************************************");
		System.out.println(System.getenv("HOME"));
		System.out.println(System.getenv("USER"));
		System.out.println(System.getenv("DESKTOP_SESSION"));

		Map<Empleado,Auto>mapaEmpleadosAutos=new LinkedHashMap();

		Empleado macarena=new Empleado(1, "Macarena");
		Empleado miguel=new Empleado(2, "Miguel");
		Empleado julio=new Empleado(3, "Julio");

		mapaEmpleadosAutos.put(macarena, lista2.get(4));
		mapaEmpleadosAutos.put(miguel, lista2.get(5));
		mapaEmpleadosAutos.put(julio, lista2.get(7));

		mapaEmpleadosAutos.forEach((e,a)->System.out.println(e+": "+a));
		System.out.println("**************************");
		//Que auto usa Miguel?
		System.out.println(mapaEmpleadosAutos.get(miguel));

		System.out.println("**************************");
		//Que auto usa Julio?
		mapaEmpleadosAutos.keySet().forEach(e->{
			if(e.getNombre().equalsIgnoreCase("julio")) 
				System.out.println(mapaEmpleadosAutos.get(e));
		});

		//Versión api stream
		//momento de delirio de código
		System.out.println(
			mapaEmpleadosAutos
					.get(mapaEmpleadosAutos
											.keySet()
											.stream()
											.filter(e->e.getNombre().equalsIgnoreCase("julio"))
											.findAny()
											.get())
		); //Olvidalooooooooooo

		//TODO Enums
		Cliente cliente=new Cliente(1, "Jimena", EstadoCivil.CASADO, Genero.FEMENINO);
		System.out.println(cliente);

		//TODO SQL
	}

}
