package ar.com.eduit.curso.java.clase06;

public enum Genero {
    FEMENINO,
    MASCULINO,
    X
}
