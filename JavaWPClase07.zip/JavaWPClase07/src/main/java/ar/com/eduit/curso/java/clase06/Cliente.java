package ar.com.eduit.curso.java.clase06;

public class Cliente {
    private int nro;
    private String nombre;
    //private String estado_civil;    // soltero, casado, viudo, divorciado
    //private String genero;          // femenino, masculino, x
    private EstadoCivil estado_civil;
    private Genero genero;
    
    public Cliente(int nro, String nombre, EstadoCivil estado_civil, Genero genero) {
        this.nro = nro;
        this.nombre = nombre;
        this.estado_civil = estado_civil;
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Cliente [nro=" + nro + ", nombre=" + nombre + ", estado_civil=" + estado_civil + ", genero=" + genero
                + "]";
    }

    public int getNro() {
        return nro;
    }

    public void setNro(int nro) {
        this.nro = nro;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public EstadoCivil getEstado_civil() {
        return estado_civil;
    }

    public void setEstado_civil(EstadoCivil estado_civil) {
        this.estado_civil = estado_civil;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

}
