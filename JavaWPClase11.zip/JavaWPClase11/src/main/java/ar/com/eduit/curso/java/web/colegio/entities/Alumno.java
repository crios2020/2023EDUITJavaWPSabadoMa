package ar.com.eduit.curso.java.web.colegio.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Alumno {
    
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private int id_curso;

    public Alumno(String nombre, String apellido, int edad, int id_curso) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.id_curso = id_curso;
    }

    
}
